
#################### Manipulates data #################### 



print("================ EXPLORACIÓN LISTA !!!! ====================") # Debugging flags


 # 6.1 (T1-4) Muestra las primeras y las últimas 6 observaciones de la base de datos en la consola.

head(duncan)
tail(duncan)
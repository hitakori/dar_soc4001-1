

#################### Manipulates data #################### 


# Visualizar datos

essdata

dim(essdata) 

head(essdata)

tail(essdata)

attributes(essdata)

str(essdata)

summary(essdata)

summary(essdata$eisced)


